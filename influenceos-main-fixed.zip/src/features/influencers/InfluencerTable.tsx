type Influencer = {
  id: string
  name: string
  handle: string
  platform: string
  followers: string
  engagement: string
  category: string
  country: string
  status: string
  profileImage: string
}

type InfluencerTableProps = {
  influencers: Influencer[]
}

function InfluencerTable({ influencers }: InfluencerTableProps) {
  return (
    <div className="overflow-hidden rounded-2xl border border-slate-800 bg-slate-900/80 shadow-lg shadow-slate-950/20">
      <table className="min-w-full divide-y divide-slate-800 text-left text-sm">
        <thead className="bg-slate-950/70 text-slate-400">
          <tr>
            <th className="px-4 py-3 font-medium">Creator</th>
            <th className="px-4 py-3 font-medium">Platform</th>
            <th className="px-4 py-3 font-medium">Followers</th>
            <th className="px-4 py-3 font-medium">Engagement</th>
            <th className="px-4 py-3 font-medium">Category</th>
            <th className="px-4 py-3 font-medium">Country</th>
            <th className="px-4 py-3 font-medium">Status</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-800 text-slate-300">
          {influencers.map((influencer) => (
            <tr key={influencer.id} className="hover:bg-slate-800/70">
              <td className="px-4 py-3">
                <div className="flex items-center gap-3">
                  <img src={influencer.profileImage} alt={influencer.name} className="h-10 w-10 rounded-full object-cover" />
                  <div>
                    <p className="font-semibold text-white">{influencer.name}</p>
                    <p className="text-xs text-slate-500">{influencer.handle}</p>
                  </div>
                </div>
              </td>
              <td className="px-4 py-3">{influencer.platform}</td>
              <td className="px-4 py-3">{influencer.followers}</td>
              <td className="px-4 py-3">{influencer.engagement}</td>
              <td className="px-4 py-3">{influencer.category}</td>
              <td className="px-4 py-3">{influencer.country}</td>
              <td className="px-4 py-3">
                <span className="rounded-full border border-emerald-500/30 bg-emerald-500/10 px-2.5 py-1 text-xs text-emerald-300">
                  {influencer.status}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

export default InfluencerTable
